- Creo un HTML con únicamente dos elementos; un botón y un párrafo.

- Creo una variable que registre el número de totalClicks realizados y la declaro iniciada en 0.

- Aplico un querySelector al botonPulsar para añadirle un addEventListener que le sume uno a la cifra
  de clicks. Después sustituyo el texto del parrafo creado en el HTML (resultado) por el texto del innerHTML con la variable
  totalClicks incluída en el medio.

- Añado style aplicando grid para situar visualmente el botón y el párrafo con el resultado a la altura de la pantalla deseada.
