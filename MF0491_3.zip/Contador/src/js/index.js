//Creo la variable que registre el número de totalClicks realizados y la declaro iniciada en 0.
let totalClicks = 0;

//Aplico un querySelector al botonPulsar para añadirle un addEventListener que le sume uno a la cifra
//de clicks. Después sustituyo el texto del parrafo HTML (resultado) por el texto del innerHTML con la variable
//totalClicks incluída en el medio.
document.querySelector("#botonPulsar").addEventListener("click", () => {
  totalClicks = totalClicks + 1;
  document.querySelector("#resultado").innerText =
    "Has pulsado el botón " + totalClicks + " veces";
});
