   for (let inner = 1; inner < 10; inner++) {
       for (let outer = 1; outer < 10; outer++){
        console.log(`Multiplicar: ${outer} x ${inner}`);
       }
   }
   console.log("\n")
        