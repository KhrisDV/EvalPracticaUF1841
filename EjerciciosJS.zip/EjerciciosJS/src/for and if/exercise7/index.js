const numbers = ["Frodo","Gandalf","Turin","Sauron","Saruman","Bilbo"];

for(let idx=3;idx<6;idx++){
        console.log(numbers[idx])
}