let number = 0;

function plusone(number) {
  resultado = number + 1;
  return resultado;
}

plusone(0);

console.log(resultado);
