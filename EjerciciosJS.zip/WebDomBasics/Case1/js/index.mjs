import { data } from "./models/main.mjs";
import {dataToHTMLList} from "./controllers/main.mjs";

dataToHTMLList(data);