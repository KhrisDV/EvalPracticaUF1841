const runners = [
  {
    name: "Lucía",
    time: 20.21,
  },
  {
    name: "Xan",
    time: 24.3,
  },
  {
    name: "Lolo",
    time: 30.11,
  },
  {
    name: "Ana",
    time: 21.18,
  },
  {
    name: "Vego",
    time: 28.13,
  },
];

export default runners;
